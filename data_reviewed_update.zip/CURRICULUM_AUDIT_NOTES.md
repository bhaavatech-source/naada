# Nāda Vidyā curriculum data review — update notes

## Files updated
- `data/mmg/dhatu.ts`

## Verified correction
The three Dāṭu varisai exercises were replaced with the three numbered Dāṭu patterns shown in the supplied *karnATik Beginners' Lessons Notation* (January 2002), pages 24–27. The previous first exercise was the zigzag sequence corresponding to the reference's pattern 2, while the reference's pattern 1 (paired-note leaps) was missing. The corrected file now includes patterns 1, 2, and 3 in source order, with 20 lines each. `display` and `tokens` are identical for each line.

## Other supplied references reviewed
- `Daatu-svaraalu.pdf`: scanned Telugu source; its visible pages include numbered Dāṭu exercises in Māyāmāḷavagauḷa.
- `Alankaaraalu.pdf`: scanned Telugu source with tala names, anga counts, and exercise patterns.
- `Music_notes_for_beginners.pdf`: machine-readable karnATik reference; includes Sarali (pp. 5–11), Janta (pp. 12–23), Dāṭu (pp. 24–27), Mēlsthāyi (pp. 28–30), Mandra sthāyi (pp. 31–33), and Alankārams (pp. 34–41).
- `72_Ragas_&_Swaras.pdf`: scanned table of 72 Melakarta rāgas and their ārohaṇa/avarohaṇa.

## Important scope and accuracy note
This is a conservative correction, not a certification that every item in the archive is now musically correct. The supplied references do not always present the same exercise variants or notation conventions. I have not silently overwritten Janta, Sarali, Mēlsthāyi, Mandra sthāyi, or Alankāram variants where the difference could be a legitimate teaching variant rather than a proven error. The scanned Telugu PDFs also need line-by-line transcription/verification before they can safely serve as a complete machine-readable source. A qualified Carnatic music teacher should review the final curriculum before it is used as instructional material.

## Validation performed
- Dāṭu exercises found: 3
- Lines per Dāṭu exercise: 20 each
- `display`/`tokens` mismatches in corrected Dāṭu file: 0
