// src/data/mmg/mandrasthayi.ts

import type { VarisaiExercise } from './types';

export const mandrasthayiVarisaiMmg: VarisaiExercise[] = [
  {
    id: 'mandrasthayi-1',
    kind: 'mandhraSthayiVarisai',
    name: 'Mandrasthāyi 1',
    raga: 'Mayamalavagowla',
    tala: 'Adi',
    notes: 'Introduction to lower octave phrasing touching Mandra Nishadha (Ṇ).',
    lines: [
      {
        display: 'Ṡ N D P | M G | R S ||',
        tokens:  'Ṡ N D P | M G | R S ||',
      },
      {
        display: 'S , , , | S , | , , ||',
        tokens:  'S , , , | S , | , , ||',
      },
      {
        display: 'G R S Ṇ | S R | G M ||',
        tokens:  'G R S Ṇ | S R | G M ||',
      },
      {
        display: 'S R G M | P D | N Ṡ ||',
        tokens:  'S R G M | P D | N Ṡ ||',
      },
    ],
  },

  {
    id: 'mandrasthayi-2',
    kind: 'mandhraSthayiVarisai',
    name: 'Mandrasthāyi 2',
    raga: 'Mayamalavagowla',
    tala: 'Adi',
    notes: 'Extended lower octave sequence exploring Mandra Nishadha (Ṇ) iteratively.',
    lines: [
      {
        display: 'Ṡ N D P | M G | R S ||',
        tokens:  'Ṡ N D P | M G | R S ||',
      },
      {
        display: 'S , , , | S , | , , ||',
        tokens:  'S , , , | S , | , , ||',
      },
      {
        display: 'G R S Ṇ | S S | Ṇ S ||',
        tokens:  'G R S Ṇ | S S | Ṇ S ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'S R G M | P D | N Ṡ ||',
        tokens:  'S R G M | P D | N Ṡ ||',
      },
    ],
  },

  {
    id: 'mandrasthayi-3',
    kind: 'mandhraSthayiVarisai',
    name: 'Mandrasthāyi 3',
    raga: 'Mayamalavagowla',
    tala: 'Adi',
    notes: 'Descending phrases extending down to Mandra Dhaivata (Ḍ).',
    lines: [
      {
        display: 'Ṡ N D P | M G | R S ||',
        tokens:  'Ṡ N D P | M G | R S ||',
      },
      {
        display: 'S , , , | S , | , , ||',
        tokens:  'S , , , | S , | , , ||',
      },
      {
        display: 'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
        tokens:  'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S S | Ṇ S ||',
        tokens:  'G R S Ṇ | S S | Ṇ S ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S R | G M ||',
        tokens:  'G R S Ṇ | S R | G M ||',
      },
      {
        display: 'S R G M | P D | N Ṡ ||',
        tokens:  'S R G M | P D | N Ṡ ||',
      },
    ],
  },

  {
    id: 'mandrasthayi-4',
    kind: 'mandhraSthayiVarisai',
    name: 'Mandrasthāyi 4',
    raga: 'Mayamalavagowla',
    tala: 'Adi',
    notes: 'Extended exercise reaching into Mandra Panchama (P̣).',
    lines: [
      {
        display: 'Ṡ N D P | M G | R S ||',
        tokens:  'Ṡ N D P | M G | R S ||',
      },
      {
        display: 'S , , , | S , | , , ||',
        tokens:  'S , , , | S , | , , ||',
      },
      {
        display: 'G R S Ṇ | Ḍ P̣ | D Ṇ ||',
        tokens:  'G R S Ṇ | Ḍ P̣ | D Ṇ ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
        tokens:  'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S S | Ṇ S ||',
        tokens:  'G R S Ṇ | S S | Ṇ S ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S R | G M ||',
        tokens:  'G R S Ṇ | S R | G M ||',
      },
      {
        display: 'S R G M | P D | N Ṡ ||',
        tokens:  'S R G M | P D | N Ṡ ||',
      },
    ],
  },

  {
    id: 'mandrasthayi-5',
    kind: 'mandhraSthayiVarisai',
    name: 'Mandrasthāyi 5',
    raga: 'Mayamalavagowla',
    tala: 'Adi',
    notes: 'Deep octave jumps stretching down to Mandra Madhyama (Ṃ).',
    lines: [
      {
        display: 'Ṡ N D P | M G | R S ||',
        tokens:  'Ṡ N D P | M G | R S ||',
      },
      {
        display: 'S , , , | S , | , , ||',
        tokens:  'S , , , | S , | , , ||',
      },
      {
        display: 'G R S Ṇ | Ḍ P̣ | Ṃ P̣ ||',
        tokens:  'G R S Ṇ | Ḍ P̣ | Ṃ P̣ ||',
      },
      {
        display: 'D Ṇ S R | G M | P M ||',
        tokens:  'D Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | Ḍ P̣ | D Ṇ ||',
        tokens:  'G R S Ṇ | Ḍ P̣ | D Ṇ ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
        tokens:  'G R S Ṇ | Ḍ Ṇ | S Ṇ ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S S | Ṇ S ||',
        tokens:  'G R S Ṇ | S S | Ṇ S ||',
      },
      {
        display: 'S Ṇ S R | G M | P M ||',
        tokens:  'S Ṇ S R | G M | P M ||',
      },
      {
        display: 'G R S Ṇ | S R | G M ||',
        tokens:  'G R S Ṇ | S R | G M ||',
      },
      {
        display: 'S R G M | P D | N Ṡ ||',
        tokens:  'S R G M | P D | N Ṡ ||',
      },
    ],
  },
];